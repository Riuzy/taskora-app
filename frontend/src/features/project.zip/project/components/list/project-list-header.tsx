"use client";

import { Plus } from "lucide-react";

import { Button } from "@/components/ui/button";

interface ProjectListHeaderProps {
    onCreate: () => void;
}

export function ProjectListHeader({
    onCreate,
}: ProjectListHeaderProps) {
    return (
        <div className="flex items-center justify-between">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">
                    Projects
                </h1>

                <p className="text-muted-foreground">
                    Manage your team's projects.
                </p>
            </div>

            <Button onClick={onCreate}>
                <Plus className="mr-2 h-4 w-4" />

                New Project
            </Button>
        </div>
    );
}