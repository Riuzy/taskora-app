"use client";

import { ReactNode } from "react";

import { useParams } from "next/navigation";

import { useProject } from "@/features/project/hooks/use-project";

import {
    ProjectPageHeader,
} from "@/features/project/components/workspace";

interface LayoutProps {
    children: ReactNode;
}

export default function ProjectLayout({
    children,
}: LayoutProps) {
    const params = useParams();

    const uuid = params.uuid as string;

    const {
        data: project,
        isLoading,
    } = useProject(uuid);

    if (isLoading) {
        return null;
    }

    if (!project) {
        return null;
    }

    return (
        <div className="space-y-6">
            <ProjectPageHeader
                project={project}
            />

            <div className="rounded-xl border p-6">
                {children}
            </div>
        </div>
    );
}