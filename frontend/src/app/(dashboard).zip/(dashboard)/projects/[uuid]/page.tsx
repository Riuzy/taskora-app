"use client";

import { useParams } from "next/navigation";

import { useProject } from "@/features/project/hooks/use-project";

export default function ProjectOverviewPage() {
    const params = useParams();

    const uuid = params.uuid as string;

    const {
        data: project,
        isLoading,
    } = useProject(uuid);

    if (!project) {
        return null;
    }

    return (
            <div >
                Overview
            </div>
    );
}