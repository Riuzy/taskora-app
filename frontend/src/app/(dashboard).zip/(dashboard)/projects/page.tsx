import { ProjectsPage } from "@/features/project/pages/project-page";

export default function Page() {
    return <ProjectsPage />;
}