import TeamsPage from "@/features/team/pages/teams-page";

export default function Page() {
    return <TeamsPage />;
}