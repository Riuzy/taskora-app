import UsersPage from "@/features/user/pages/users-page";

export default function Page() {
    return <UsersPage />;
}