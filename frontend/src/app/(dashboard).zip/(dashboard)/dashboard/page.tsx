export default function DashboardPage() {
  return (
    <div>

      <h1 className="text-3xl font-bold tracking-tight">
        Dashboard
      </h1>

      <p className="mt-2 text-slate-500">
        Welcome back. Here's what's happening today.
      </p>

    </div>
  );
}